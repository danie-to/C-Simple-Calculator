package pkg1stqtr_pt1_calculator;

import java.util.Scanner;

class Main {
    
    
    public static Double mycalculate(Double op1, String opr, Double op2)
    {
        Double result=0.0;
        
        if(opr.equals("+"))
        {
            result = op1 + op2;
        } else if(opr.equals("-"))
        {
            result = op1 - op2;
        } else if(opr.equals("*"))
        {
            result = op1 * op2;
        } else if(opr.equals("/"))
        {
            result = op1 / op2;
        } else
        {
            System.out.println("Invalid input. Please try again!");
        }
       
        //System.out.println("The result is " + result);
        
        return result;
    }
    
    public static void main(String[] args) {
        
        boolean programIsRunning = true;
        
        while (programIsRunning) {
        
        System.out.println("===== CALCULATOR ===== \n");
        
        Scanner sc1 = new Scanner(System.in);
        System.out.println("Enter 1st number:");
        Double op1 = Double.parseDouble(sc1.nextLine());
        
        System.out.println("Enter the operation (+-*/):");
        String opr = sc1.nextLine();
        
        System.out.println("Enter 2nd number:");
        Double op2 = Double.parseDouble(sc1.nextLine());
        
        //Double result=0.0;
        Double result = mycalculate(op1, opr, op2);
        System.out.println("The result in " + result);
        
        }
    }
}
